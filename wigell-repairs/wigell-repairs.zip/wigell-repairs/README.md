# Wigell Repairs - Microservice (Spring Boot)

Port: **5555**

## Quick start (Docker Compose)
1. Build and run:
   ```bash
   docker compose up --build

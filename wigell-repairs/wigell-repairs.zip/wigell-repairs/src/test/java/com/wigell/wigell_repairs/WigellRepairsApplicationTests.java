package com.wigell.wigell_repairs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WigellRepairsApplicationTests {

	@Test
	void contextLoads() {


	}

}

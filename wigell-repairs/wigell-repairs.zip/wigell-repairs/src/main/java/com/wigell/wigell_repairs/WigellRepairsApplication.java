package com.wigell.wigell_repairs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WigellRepairsApplication {
	public static void main(String[] args) {
		SpringApplication.run(WigellRepairsApplication.class, args);
	}
}

package com.wigell.wigell_repairs.entity;

public enum ServiceType {
    CAR,
    ELECTRONICS,
    APPLIANCES,
    OTHER
}
